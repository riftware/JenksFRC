/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package robotichello;

/**
 *
 * @author robotics
 */
public class MainProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int incredibleVariable;
        incredibleVariable=0;
        for(int x=0;x <= 20;x++){
            System.out.println("Fun with Counting :" + x);
        }
// TODO code application logic here
        System.out.println("Hello World");
        
    }
    
}
