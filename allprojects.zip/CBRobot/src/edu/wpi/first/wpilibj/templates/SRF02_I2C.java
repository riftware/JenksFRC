/*
 * @(#)SRF02_I2C.java   01/24/13
 * 
 * Copyright (c) 2012 Williams Company
 *
 * License agreement text here ...
 *
 *
 *
 */
package edu.wpi.first.wpilibj.templates;
//~--- non-JDK imports --------------------------------------------------------
import edu.wpi.first.wpilibj.templates.subsystems.*;
import edu.wpi.first.wpilibj.DigitalModule;
import edu.wpi.first.wpilibj.I2C;
import edu.wpi.first.wpilibj.SensorBase;
import edu.wpi.first.wpilibj.parsing.ISensor;
//~--- classes ----------------------------------------------------------------
/**
 *
 * @author andy
 */
public class SRF02_I2C extends SensorBase implements ISensor {
    private static final char kAddress                 = (char) 0xE0;
    private static final char kAddress2                = (char) 0x71;
    private static final char kAddress3                = (char) 0x72;
    private static final byte kCommandRegister         = 0x00;
    private static final byte kRangeHighByte           = 0x02;
    private static final byte kRangeLowByte            = 0x03;
    private static final byte kRangeInchesCommand      = 0x50;
    private static final byte kRangeCentimetersCommand = 0x51;
    private byte[]            buffer;
    private byte[]            buffer2;
    private byte[]            buffer3;
    private I2C               m_i2c;
    private I2C               m_i2c2;
    private I2C               m_i2c3;

    /**
     * Constructs ...
     *
     *
     * @param slot
     */
    public SRF02_I2C(int slot) {
        DigitalModule module = DigitalModule.getInstance(slot);
        m_i2c  = module.getI2C(kAddress);
        m_i2c2  = module.getI2C(kAddress2);
        m_i2c3  = module.getI2C(kAddress3);
        m_i2c.setCompatabilityMode(true);
        m_i2c2.setCompatabilityMode(true);
        m_i2c3.setCompatabilityMode(true);
        buffer = new byte[4];
        buffer2= new byte[4];
    }

    
          // documentation seems to indicate with i2c most times if you try to read more than 1 byte the device
        // will usually increment the location for you.   Hence starting at 0 and asking for 4 bytes SHOULD give us
        // the command register, Unused register (reads 0x80), Range High Byte, Range Low Byte all in one read.
        // The srf02 will not respond on the command register until the ping and calculation is complete
    
    public short[] getRangeInches() {
        boolean bSuccess = false;
        boolean bSuccess2= false;
        boolean bSuccess3= false;
        short[]  result  = new short[3];
        result[0]=0;
        result[1]=0;
        result[2]=0;
  
//        m_i2c.read(kCommandRegister, 1, buffer);
//        System.out.println("Buffer is :" + buffer[0]);
//        result = buffer[0];
                
        m_i2c.write(kCommandRegister, kRangeInchesCommand);
        m_i2c2.write(kCommandRegister, kRangeInchesCommand);
        m_i2c3.write(kCommandRegister, kRangeInchesCommand);
        while (!bSuccess) {
            m_i2c.read(kCommandRegister, 4, buffer);
            //System.out.println("Return array: " + buffer.toString());
            if (buffer[0] != 0xFF) {
                bSuccess = true;
            } else {
                try {
                    Thread.currentThread().sleep(10);    // takes up to 66ms after you initiate ranging so slow loop down
                } catch (InterruptedException ie) {

                    // don't have to actually do anything with the exception except leave loop maybe
                    break;
                }
            }
        }

        if(bSuccess){
        result[0] = (short) (buffer[2] * 256);
        result[0] = (short) (result[0] + buffer[3]);
        
        
        
        // if lowByte and highByte aren't actually being populated by that single 4 byte read use next 4 comment lines instead
//            m_i2c.read(kRangeHighByte, 1, buffer);  
//            result = buffer[0] * 256;
//            m_i2c.read(kRangeLowByte, 1, buffer);
//            result = result + buffer[0];
        
           }
            while (!bSuccess2) {
            m_i2c2.read(kCommandRegister, 4, buffer2);
            //System.out.println("Return array: " + buffer.toString());

            if (buffer2[0] != 0xFF) {
                bSuccess2 = true;
            } else {
                try {
                    Thread.currentThread().sleep(10);    // takes up to 66ms after you initiate ranging so slow loop down
                } catch (InterruptedException ie) {

                    // don't have to actually do anything with the exception except leave loop maybe
                    break;
                }
            }
        }

        if(bSuccess2){
        result[1] = (short) (buffer2[2] * 256);
        result[1] = (short) (result[1] + buffer2[3]);
        
        
        
        // if lowByte and highByte aren't actually being populated by that single 4 byte read use next 4 comment lines instead
//            m_i2c.read(kRangeHighByte, 1, buffer);  
//            result = buffer[0] * 256;
//            m_i2c.read(kRangeLowByte, 1, buffer);
//            result = result + buffer[0];
        
           }
        while (!bSuccess3) {
            m_i2c3.read(kCommandRegister, 4, buffer3);
            //System.out.println("Return array: " + buffer.toString());
            if (buffer3[0] != 0xFF) {
                bSuccess3 = true;
            } else {
                try {
                    Thread.currentThread().sleep(10);    // takes up to 66ms after you initiate ranging so slow loop down
                } catch (InterruptedException ie) {

                    // don't have to actually do anything with the exception except leave loop maybe
                    break;
                }
            }
        }

        if(bSuccess3){
        result[3] = (short) (buffer3[2] * 256);
        result[3] = (short) (result[0] + buffer3[3]);
        
        
        
        // if lowByte and highByte aren't actually being populated by that single 4 byte read use next 4 comment lines instead
//            m_i2c.read(kRangeHighByte, 1, buffer);  
//            result = buffer[0] * 256;
//            m_i2c.read(kRangeLowByte, 1, buffer);
//            result = result + buffer[0];
        
           }
        return result;
    }
}
