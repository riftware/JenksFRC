/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates.subsystems;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.templates.RobotMap;
/**
 *
 * @author robotics
 */
public class Launcher {
    public static boolean fire(){
        RobotMap.spike.set(Relay.Value.kForward);
        while(!RobotMap.inputs.get()){
        }
        RobotMap.spike.set(Relay.Value.kOff);
        return true;
    }
}
