/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates.commands;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.templates.RobotMap;
import edu.wpi.first.wpilibj.templates.subsystems.Chassis;
/**
 *
 * @author robotics
 */
public class DriveChain extends CommandBase {
    private static Subsystem chassis;
    private static Chassis Chassis;
    public DriveChain(){
        super.requires(chassis);
    }
    // Called just before this Command runs the first time
    protected void initialize() {
    }
    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
        double speed=RobotMap.leftStick.getAxis(Joystick.AxisType.kZ);
        double ratio=RobotMap.leftStick.getAxis(Joystick.AxisType.kX);
        if(ratio!=0){
            Chassis.turn(speed, ratio);
        }else{
            Chassis.forward(speed);
        }
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return false;
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
