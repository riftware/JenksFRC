package edu.wpi.first.wpilibj.templates.subsystems;
import edu.wpi.first.wpilibj.templates.commands.DriveChain;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.templates.RobotMap;
public class Chassis extends Subsystem{
    private DriveChain DriveChain=new DriveChain();
    public static void forward(double speed){
        RobotMap.mainDrive.tankDrive(speed, speed);
    }
    public static void turn(double max, double ratio){
        double[] motors=new double[2];
       if(ratio>0){
           motors[0]=max;
           motors[1]=max*(1-Math.abs(ratio));
       }else if(ratio<0){
           motors[1]=max;
           motors[0]=max*(1-Math.abs(ratio));
       }else{
           motors[0]=max;
           motors[1]=max;
       }
       if(max==0){
           if(ratio!=0){
               motors[0]=ratio;
               motors[1]=ratio*-1;
           }else{
               motors[0]=0;
               motors[1]=0;
           }
       }
    }

    protected void initDefaultCommand() {
        super.setDefaultCommand(DriveChain);
    }
}
