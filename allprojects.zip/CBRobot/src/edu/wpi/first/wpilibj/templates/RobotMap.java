package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.RobotDrive;
/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
    public static final DigitalInput inputs=new DigitalInput(1,11);
    public static final RobotDrive mainDrive=new RobotDrive(1,2);
    public static final Joystick leftStick=new Joystick(1);
    public static final Jaguar launcher=new Jaguar(3);
    public static final SRF02_I2C ultrasonic=new SRF02_I2C(1);
    public static final Relay spike=new Relay(1);
    public static final DigitalAccelerometer accelerometer=new DigitalAccelerometer(1);
    public static final Gyro gyro1=new Gyro(1);
}
