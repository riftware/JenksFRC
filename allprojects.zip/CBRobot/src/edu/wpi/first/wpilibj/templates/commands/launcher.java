/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates.commands;
import edu.wpi.first.wpilibj.templates.subsystems.Launcher;
/**
 *
 * @author robotics
 */
public class launcher extends CommandBase{
    private boolean finished=false;
    protected void initialize() {
    }

    protected void execute() {
        finished=Launcher.fire();
    }

    protected boolean isFinished() {
        return finished;
    }

    protected void end() {
    }

    protected void interrupted() {
    }
    
}
