/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.can.CANTimeoutException;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class RobotTemplate extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    private CANJaguar frontLeft;
    private CANJaguar frontRight;
    private CANJaguar backLeft;
    private CANJaguar backRight;
    private CANJaguar winch;
    private DigitalInput limit;
    private DigitalInput pressureSwitch;
    private Joystick joystick;
    private Relay armSpike;
    private Relay pump;
    private Relay quickRelease;
    private RobotDrive mainDrive;
    private Gyro gyro;
    
    private void initRobot(){
        gyro=new Gyro(2);
        limit=new DigitalInput(9);
        pressureSwitch=new DigitalInput(8);
        joystick=new Joystick(1);
        armSpike=new Relay(4);
        pump=new Relay(3);
        quickRelease=new Relay(2);
        try {
            frontLeft=new CANJaguar(2);
            frontRight=new CANJaguar(3);
            backLeft=new CANJaguar(4);
            backRight=new CANJaguar(5);
            winch=new CANJaguar(6);
        } catch (CANTimeoutException ex) {
            ex.printStackTrace();
        }
        mainDrive=new RobotDrive(frontLeft,backLeft,frontRight,backRight);
    }
    
    public void autonomous() {
        
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        initRobot();
        while(true){
            double motors[]=getMecanumVals();
            armSpike.setDirection(Relay.Direction.kForward);
            pump.setDirection(Relay.Direction.kForward);
            quickRelease.setDirection(Relay.Direction.kForward);
            mainDrive.mecanumDrive_Cartesian(motors[0], motors[1], motors[2], motors[3]);
            if(!pressureSwitch.get()){
                pump.set(Relay.Value.kOn);
            }else if(pressureSwitch.get()){
                pump.set(Relay.Value.kOff);
            }
            if(joystick.getRawButton(1)){
                quickRelease.set(Relay.Value.kOn);
                if(limit.get()){
                    winch.set(joystick.getRawAxis(5));
                }else{
                    double temp=joystick.getRawAxis(5);
                    if(temp<0){
                        temp=0;
                    }
                    winch.set(temp);
                }
            }else if(!joystick.getRawButton(1)){
                quickRelease.set(Relay.Value.kOff);
                if(joystick.getRawButton(4)){
                    if(limit.get()){
                        winch.set(joystick.getRawAxis(5));
                    }else{
                        double temp=joystick.getRawAxis(5);
                        if(temp<0){
                            temp=0;
                        }
                        winch.set(temp);
                    }
                }else{
                    winch.set(0);
                }
            }
            if(joystick.getRawButton(3)){
                armSpike.set(Relay.Value.kOn);
            }else{
                armSpike.set(Relay.Value.kOff);
            }
        }

    }
    
    /**
     * This function is called once each time the robot enters test mode.
     */
    public void test() {
    
    }
    
    //Tank Drive Method
    
//    public double[] getMotors(){
//       double max=joystick.getAxis(Joystick.AxisType.kZ);
//       double ratio=joystick.getAxis(Joystick.AxisType.kX);
//       double[] motors=new double[2];
//       if(ratio<0){
//           motors[0]=max;
//           motors[1]=max*(1-Math.abs(ratio));
//       }else if(ratio>0){
//           motors[1]=max;
//           motors[0]=max*(1-Math.abs(ratio));
//       }else{
//           motors[0]=max;
//           motors[1]=max;
//       }
//       if(max==0){
//           if(ratio!=0){
//               motors[0]=ratio;
//               motors[1]=ratio*-1;
//           }else{
//               motors[0]=0;
//               motors[1]=0;
//           }
//       }
//       return motors;
//    }
    
    public double[] getMecanumVals(){
        double[] vals=new double[4];
        vals[0]=joystick.getAxis(Joystick.AxisType.kY);
        vals[1]=-joystick.getRawAxis(6)/4;
        vals[2]=-joystick.getAxis(Joystick.AxisType.kX);
        vals[3]=gyro.getAngle();
        for (int i=0;i<3;i++){
            if(Math.abs(vals[i])<.15){
                vals[i]=0;
            }
        }
        return vals;
    }
}
