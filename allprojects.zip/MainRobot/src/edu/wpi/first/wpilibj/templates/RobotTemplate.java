package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.ADXL345_I2C;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.Timer;
public class RobotTemplate extends SimpleRobot {
   // public static final ADXL345_I2C.DataFormat_Range rangeVal =ADXL345_I2C.DataFormat_Range.k2G ;
   // Servo camera=new Servo(1,8);
    Gyro gyro1=new Gyro(1);
    ADXL345_I2C accelerometer=new ADXL345_I2C(1, ADXL345_I2C.DataFormat_Range.k2G);
    SRF02_I2C ultrasonic=new SRF02_I2C(1);
    RobotDrive mainDrive=new RobotDrive(2,3);
    Joystick leftStick=new Joystick(1);
    Joystick rightStick=new Joystick(2);
    public void autonomous() {
        System.out.println("This is autonomous mode");
    }
    public void operatorControl() {
        mainDrive.setSafetyEnabled(true);
        int v=0;
        System.out.println("About to start looping");
        while(isOperatorControl()&&isEnabled()){
            //System.out.println("still looping  "+v);
            double[] motors=new double[2];
            
            motors=joystickLimiter();
            //System.out.println(motors[0]+"  "+motors[1]);
            //System.out.println(camera.getAngle()+"   ,   "+camera.get());
           //camera.setAngle(90);
           // Timer.delay(1);
           // camera.setAngle(0);
            //Timer.delay(5);
            //camera.set(0);
            v++;
            //AllAxes axes=accelerometer.getAccelerations();
            mainDrive.tankDrive(0, leftStick.getAxis(Joystick.AxisType.kY));
            Timer.delay(0.01);
            //if(axes.XAxis>1.5||axes.YAxis>1.5||axes.ZAxis>1.5){
            //    break;
            //}
        }
        System.out.println("Stopped looping");
    }
    public void test() {
        System.out.println("This is test mode");
    }
    public double[] joystickLimiter(){
        double[] motors=new double[2];
        double[] sticks=new double[3];
        sticks[0]=leftStick.getAxis(Joystick.AxisType.kY);
        sticks[1]=leftStick.getAxis(Joystick.AxisType.kY);
        sticks[2]=leftStick.getAxis(Joystick.AxisType.kX);
        if(sticks[2]<-.1){
            if(sticks[1]<-.2){
                motors[0]=-.5;
                motors[1]=-.25;
            }else if(sticks[1]>.2){
                motors[0]=.5;
                motors[1]=.25;
            }else{
                motors[0]=-.5;
                motors[1]=.5;
            }
        }else if(sticks[2]>.1){
            if(sticks[1]<-.2){
                motors[0]=.5;
                motors[1]=.25;
            }else if(sticks[1]>.2){
                motors[0]=.5;
                motors[1]=.25;
            }else{
                motors[0]=.5;
                motors[1]=-.5;
            }
        }else if(sticks[0]<-.1){
            if(sticks[0]<-.5){
                motors[0]=-1;
            }else{
                motors[0]=-.5;
            }
        }else if(sticks[0]>.1){
            if(sticks[0]>.5){
                motors[0]=1;
            }else{
                motors[0]=.5;
            }
        }else{
            motors[0]=0;
        }
        if(sticks[1]<-.1){
            if(sticks[1]<-.5){
                motors[1]=-1;
            }else{
                motors[1]=-.5;
            }
        }else if(sticks[1]>.1){
            if(sticks[1]>.5){
                motors[1]=1;
            }else{
                motors[1]=.5;
            }
        }else{
            motors[1]=0;
        }
        return motors;
    }
}
