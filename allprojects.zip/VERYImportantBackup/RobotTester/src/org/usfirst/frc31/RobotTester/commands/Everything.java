package org.usfirst.frc31.RobotTester.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;
import org.usfirst.frc31.RobotTester.commands.*;
public class Everything extends CommandGroup{
    public Everything(){
        System.out.println("Im in everything");
        addParallel(new Drive());
        addParallel(new Fire());
        addParallel(new WheelSpinUp());
        //addParallel(camServo);
        addSequential(new adjustServo());
    }
}
