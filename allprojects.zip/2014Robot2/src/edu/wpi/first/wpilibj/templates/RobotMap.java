package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.can.CANTimeoutException;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;

/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
    // For example to map the left and right motors, you could define the
    // following variables to use with your drivetrain subsystem.
    // public static final int leftMotor = 1;
    // public static final int rightMotor = 2;
    
    // If you are using multiple modules, make sure to define both the port
    // number and the module. For example you with a rangefinder:
    // public static final int rangefinderPort = 1;
    // public static final int rangefinderModule = 1;\
    public static CANJaguar mecanumDriveFrontLeft;
    public static CANJaguar mecanumDriveFrontRight;
    public static CANJaguar mecanumDriveBackLeft;
    public static CANJaguar mecanumDriveBackRight;
    public static RobotDrive mecanumDriveRobotDrive41;
    public static DigitalInput pressureSwitch;
    public static Relay compressorSpike;
    public static CANJaguar winch;
    public static Relay quickReleaseSpike;
    public static CANJaguar mecanumDrivefrontLeft;
    public static Gyro gyro;
    public static void init(){
        try{
            mecanumDriveFrontLeft=new CANJaguar(2);
            mecanumDriveFrontRight=new CANJaguar(3);
            mecanumDriveBackLeft=new CANJaguar(4);
            mecanumDriveBackRight=new CANJaguar(5);
            winch=new CANJaguar(6);
        }catch(CANTimeoutException ex){
        }
        
        mecanumDriveRobotDrive41=new RobotDrive(mecanumDriveFrontLeft,mecanumDriveBackLeft,mecanumDriveFrontRight,mecanumDriveBackLeft);
        mecanumDriveRobotDrive41.setSafetyEnabled(true);
        mecanumDriveRobotDrive41.setExpiration(.1);
        mecanumDriveRobotDrive41.setSensitivity(.5);
        mecanumDriveRobotDrive41.setMaxOutput(1.0);
        
        pressureSwitch=new DigitalInput(1, 8);
        LiveWindow.addSensor("compressor","pressureSwitch", pressureSwitch);
        
        compressorSpike = new Relay(1, 2);
	LiveWindow.addActuator("compressor", "compressorSpike", compressorSpike);
        
        quickReleaseSpike=new Relay(1,3);
        LiveWindow.addActuator("launcher","quickRelease",quickReleaseSpike);
        
        gyro=new Gyro(2);
    }
}
