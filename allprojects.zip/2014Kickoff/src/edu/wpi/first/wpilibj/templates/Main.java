            /*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.can.CANTimeoutException;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Main extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    private static RobotDrive mainDrive;
    private static Joystick joystick;
    private boolean beenInit=false;
    private DriverStation ds;
    private Encoder e;
    private Gyro g;
    private DigitalInput pressureSensor;
    private Relay quickRelease;
    private Relay pump;
    private CANJaguar jag1;
    private CANJaguar jag2;
    private CANJaguar jag3;
    private CANJaguar jag4;
    
    
    private void init(){
        joystick=new Joystick(1);
        beenInit=true;
        ds= DriverStation.getInstance();
        g=new Gyro(2);
        e= new Encoder(5,6, false, EncodingType.k1X);
        quickRelease=new Relay(1);
        pump=new Relay (3);
        pressureSensor=new DigitalInput(9);
        try {    
            jag1=new CANJaguar(2);
            jag2=new CANJaguar(3);
            jag3=new CANJaguar(4);
            jag4=new CANJaguar(5);
        } catch (CANTimeoutException ex) {
            ex.printStackTrace();
        }
        mainDrive=new RobotDrive(jag1,jag2,jag3,jag4);
    }
    
    public void autonomous() {
        if(!beenInit){
            init();
        }
        while(isEnabled()&&isAutonomous()){
            System.out.println(ds.getAlliance().name+"\t"+ds.getLocation());
            SmartDashboard.putNumber("Left Motor Speed", 0);
            SmartDashboard.putNumber("Right Motor Speed", 0);
            SmartDashboard.putString("Alliance", ds.getAlliance().name);
            SmartDashboard.putBoolean("Is Rampaging", true);
        }
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        if(!beenInit){
            init();
        }
//        e.start();
//        e.reset();
//        pump.setDirection(Relay.Direction.kForward);
//        quickRelease.setDirection(Relay.Direction.kForward);
//        int cycle=0;
        while(isEnabled()&&isOperatorControl()){
//            cycle++;
            System.out.println("Rate: "+g.getRate());
            System.out.println("Angle: "+g.getAngle());
            double[] motors=getMotors();
//            SmartDashboard.putNumber("Left Motor Speed", motors[0]);
//            SmartDashboard.putNumber("Right Motor Speed", motors[1]);
//            SmartDashboard.putString("Alliance", ds.getAlliance().name);
//            SmartDashboard.putBoolean("Is Rampaging", isRampaging());
//            System.out.println("1\t"+joystick.getRawAxis(1));
//            System.out.println("2\t"+joystick.getRawAxis(2));
//            System.out.println("3\t"+joystick.getRawAxis(3));
//            System.out.println("4\t"+joystick.getRawAxis(4));
//            System.out.println("5\t"+joystick.getRawAxis(5));
//            System.out.println("6\t"+joystick.getRawAxis(6));
//            System.out.println(joystick.getThrottle());
//            System.out.println(joystick.getMagnitude());
            
            if(!(pressureSensor.get())){
                pump.set(Relay.Value.kOn);
            }else{
                pump.set(Relay.Value.kOff);
            }
            if(joystick.getRawButton(1)){
//                System.out.println("ON\t"+cycle);
                quickRelease.set(Relay.Value.kOn);
            }else if(!joystick.getRawButton(1)){
                quickRelease.set(Relay.Value.kOff);
            }
            mainDrive.tankDrive(motors[0], motors[1]);
        }
        e.stop();
    }
    
    private boolean isRampaging(){
        if(isEnabled()){
            return !isOperatorControl()||isAutonomous();
        }
        return false;
    }
    
    /**
     * This function is called once each time the robot enters test mode.
     */
    public void test() {
        if(!beenInit){
            init();
        }
    }
    
    public double[] getMotors(){
       double max=joystick.getAxis(Joystick.AxisType.kZ);
       double ratio=joystick.getAxis(Joystick.AxisType.kX);
       double[] motors=new double[2];
       if(ratio<0){
           motors[0]=max;
           motors[1]=max*(1-Math.abs(ratio));
       }else if(ratio>0){
           motors[1]=max;
           motors[0]=max*(1-Math.abs(ratio));
       }else{
           motors[0]=max;
           motors[1]=max;
       }
       if(max==0){
           if(ratio!=0){
               motors[0]=ratio;
               motors[1]=ratio*-1;
           }else{
               motors[0]=0;
               motors[1]=0;
           }
       }
       return motors;
    }
}
