/*
 * @(#)SRF02_I2C.java   01/24/13
 * 
 * Copyright (c) 2012 Williams Company
 *
 * License agreement text here ...
 *
 *
 *
 */



package edu.wpi.first.wpilibj.templates;

//~--- non-JDK imports --------------------------------------------------------

import edu.wpi.first.wpilibj.DigitalModule;
import edu.wpi.first.wpilibj.I2C;
import edu.wpi.first.wpilibj.SensorBase;
import edu.wpi.first.wpilibj.parsing.ISensor;

//~--- classes ----------------------------------------------------------------

/**
 *
 * @author andy
 */
public class SRF02_I2C extends SensorBase implements ISensor {
    private static final byte kAddress                 = (byte) 0xE0;
    private static final byte kCommandRegister         = 0x00;
    private static final byte kRangeHighByte           = 0x02;
    private static final byte kRangeLowByte            = 0x03;
    private static final byte kRangeInchesCommand      = 0x50;
    private static final byte kRangeCentimetersCommand = 0x51;
    private byte[]            buffer;
    private I2C               m_i2c;

    /**
     * Constructs ...
     *
     *
     * @param slot
     */
    public SRF02_I2C(int slot) {
        DigitalModule module = DigitalModule.getInstance(slot);

        m_i2c  = module.getI2C(kAddress);
        buffer = new byte[4];
    }

    
          // documentation seems to indicate with i2c most times if you try to read more than 1 byte the device
        // will usually increment the location for you.   Hence starting at 0 and asking for 4 bytes SHOULD give us
        // the command register, Unused register (reads 0x80), Range High Byte, Range Low Byte all in one read.
        // The srf02 will not respond on the command register until the ping and calculation is complete
    
    public double getRangeInches() {
        boolean bSuccess = false;
        double  result  = 0;
  

        m_i2c.write(kCommandRegister, kRangeInchesCommand);

        while (!bSuccess) {
            m_i2c.read(kCommandRegister, 4, buffer);
            System.out.println("Return array: " + buffer.toString());
            
            if (buffer[0] != 0xFF) {
                bSuccess = true;
            } else {
                try {
                    Thread.currentThread().sleep(10);    // takes up to 66ms after you initiate ranging so slow loop down
                } catch (InterruptedException ie) {

                    // don't have to actually do anything with the exception except leave loop maybe
                    break;
                }
            }
        }

        if(bSuccess){
            System.out.println(buffer[2]);
            System.out.println(buffer[3]);
        result = buffer[2] * 256;
        result = result + buffer[3];
        
        
        
        // if lowByte and highByte aren't actually being populated by that single 4 byte read use next 4 comment lines instead
            m_i2c.read(kRangeHighByte, 1, buffer);  
            result = buffer[2] * 256;
            m_i2c.read(kRangeLowByte, 1, buffer);
            result = result + buffer[3];
        }
        return result;
    }
}
