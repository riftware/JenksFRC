/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworld;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author robotics
 */
public class HelloWorld {
    int x;
    String myString;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int counterOfLlamas=0; counterOfLlamas<100;counterOfLlamas++){
            System.out.println(counterOfLlamas);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(HelloWorld.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
