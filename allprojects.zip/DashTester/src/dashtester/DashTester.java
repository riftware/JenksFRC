package dashtester;
import 
public class DashTester {
    public static void main(String[] args) {
        
    }
    
}
