package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.Ultrasonic;
public class Main extends SimpleRobot {
    double[] motors=new double[2];
    double[] accelerations=new double[3];
    double[] distances=new double[3];
    DigitalAccelerometer accelerometer=new DigitalAccelerometer(1);
    Gyro gyro1=new Gyro(1);
    SRF02_I2C ultrasonic=new SRF02_I2C(1);
    //SRF02_I2C ultrasonic2=new SRF02_I2C(1);
    //SRF02_I2C ultrasonic3=new SRF02_I2C(1);
    RobotDrive mainDrive=new RobotDrive(1,2);
    Joystick leftStick=new Joystick(1);
    Jaguar launcher=new Jaguar(3);
    public void autonomous() {
        System.out.println("This is autonomous mode");
        launcher.set(1);
        
    }
    public void operatorControl() {
        mainDrive.setSafetyEnabled(true);
        double distanceReturned = 0.0;
        while(isOperatorControl()&&isEnabled()){
            launcher.set(leftStick.getAxis(Joystick.AxisType.kThrottle));
            getMotors();
            mainDrive.tankDrive(0, 0);
         //   getAcceleration();
           distanceReturned = ultrasonic.getRangeInches();
            System.out.println(distanceReturned);
         //   System.out.println(accelerations[0]+"  "+accelerations[1]+"   "+accelerations[2]+"  "+distances[1]);
            Timer.delay(.01);
        }
    }
    public void test() {
        System.out.println("This is test mode");
    }
    public void getMotors(){
       double max=leftStick.getAxis(Joystick.AxisType.kZ);
       double ratio=leftStick.getAxis(Joystick.AxisType.kX);
       if(ratio>0){
           motors[0]=max;
           motors[1]=max*(1-Math.abs(ratio));
       }else if(ratio<0){
           motors[1]=max;
           motors[0]=max*(1-Math.abs(ratio));
       }else{
           motors[0]=max;
           motors[1]=max;
       }
       if(max==0){
           if(ratio!=0){
               motors[0]=ratio;
               motors[1]=ratio*-1;
           }else{
               motors[0]=0;
               motors[1]=0;
           }
       }
    }
    public void getAcceleration(){
         accelerations[0]=accelerometer.getXAxis();
         accelerations[1]=accelerometer.getYAxis();
         accelerations[2]=accelerometer.getZAxis();
    }
    public double getAngle(){
//        return gyro1.getAngle();
        return 0;
    }
    public void getDistance(){
        //distances[0]=ultrasonic.getRangeInches();
        //distances[1]=ultrasonic2.getRangeInches();
        //distances[2]=ultrasonic3.getRangeInches();
    }
}
